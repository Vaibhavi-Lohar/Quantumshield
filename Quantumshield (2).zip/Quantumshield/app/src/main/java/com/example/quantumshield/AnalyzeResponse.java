package com.example.quantumshield;
import java.util.*;

public class AnalyzeResponse {
    public String label;
    public double confidence;
    public List<String> explanations;
    public int duration_ms;
}
