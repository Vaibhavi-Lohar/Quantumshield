package com.example.quantumshield;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private static final int PICK_IMAGE = 101;
    private static final int PICK_VIDEO = 102;
    private static final int PICK_AUDIO = 103;

    private Button btnImage, btnVideo, btnAudio, btnLogout;
    private TextView tvResult;
    private ApiService api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnImage = findViewById(R.id.btnImage);
        btnVideo = findViewById(R.id.btnVideo);
        btnAudio = findViewById(R.id.btnAudio);
        btnLogout = findViewById(R.id.btnLogout); // ✅ now inside onCreate
        tvResult = findViewById(R.id.tvResult);

        TextView title = findViewById(R.id.titleText);
        TextView title1 = findViewById(R.id.titleText1);


        Animation anim = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        title.startAnimation(anim);

        Animation anim1 = AnimationUtils.loadAnimation(this, R.anim.slide_in_top);
        title1.startAnimation(anim);

        Button btnMsgChecker = findViewById(R.id.msgchecker);

        btnMsgChecker.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MessageChecker.class);
            startActivity(intent);
        });

        Button map = findViewById(R.id.btnMap);

        map.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MapsActivity.class);
            startActivity(intent);
        });





        // TODO: replace with ngrok HTTPS URL from Vaibhavi (include trailing slash)
        String BASE_URL = "https://clean-queens-cheat.loca.lt/";
        api = RetrofitClient.getApi(BASE_URL);

        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA
        }, 1);

        btnImage.setOnClickListener(v -> pickFile("image/*", PICK_IMAGE));
        btnVideo.setOnClickListener(v -> pickFile("video/*", PICK_VIDEO));
        btnAudio.setOnClickListener(v -> pickFile("audio/*", PICK_AUDIO));

        // ✅ Logout button always active
        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(MainActivity.this, "You have been logged out", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, Login_Activity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void pickFile(String mime, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType(mime);
        startActivityForResult(Intent.createChooser(intent, "Select file"), requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            String filename = requestCode == PICK_IMAGE ? "upload.jpg" : (requestCode == PICK_VIDEO ? "upload.mp4" : "upload.wav");
            try {
                File file = new File(getCacheDir(), filename);
                InputStream in = getContentResolver().openInputStream(uri);
                FileOutputStream out = new FileOutputStream(file);
                byte[] buf = new byte[4096];
                int len;
                while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
                out.close();
                in.close();
                String mediaType = requestCode == PICK_IMAGE ? "image" : (requestCode == PICK_VIDEO ? "video" : "audio");
                uploadFile(file, mediaType);
            } catch (Exception e) {
                tvResult.setText("File error: " + e.getMessage());
            }
        }
    }

    private void uploadFile(File file, String mediaTypeStr) {
        tvResult.setText("Uploading...");
        RequestBody reqFile = RequestBody.create(MediaType.parse("application/octet-stream"), file);
        MultipartBody.Part body = MultipartBody.Part.createFormData("file", file.getName(), reqFile);
        RequestBody mediaType = RequestBody.create(MediaType.parse("text/plain"), mediaTypeStr);

        Call<AnalyzeResponse> call = api.analyze(mediaType, body);
        call.enqueue(new Callback<AnalyzeResponse>() {
            @Override
            public void onResponse(Call<AnalyzeResponse> call, Response<AnalyzeResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    AnalyzeResponse r = response.body();
                    String label = r.label != null ? r.label : "unknown";
                    String explanations = (r.explanations != null && !r.explanations.isEmpty()) ?
                            TextUtils.join(", ", r.explanations) : "";
                    String text = "Result: " + label.toUpperCase() +
                            "\nConfidence: " + r.confidence +
                            "\n" + explanations;
                    if ("suspicious".equalsIgnoreCase(label)) {
                        tvResult.setTextColor(Color.parseColor("#FF4444")); // red
                    } else {
                        tvResult.setTextColor(Color.parseColor("#008800")); // green
                    }
                    tvResult.setText(text);
                } else {
                    tvResult.setText("Server error: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<AnalyzeResponse> call, Throwable t) {
                tvResult.setText("Network error: " + t.getMessage());
                Log.e("MainActivity", "upload failed", t);
            }
        });



    }
}
