package com.example.quantumshield;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.google.i18n.phonenumbers.geocoding.PhoneNumberOfflineGeocoder;

import java.util.Locale;

public class MessageChecker extends AppCompatActivity {

    EditText etMessage, etPhone;
    Button btnCheck, btnCheckPhone;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_checker); // ✅ match your XML filename

        // Link XML elements
        etMessage = findViewById(R.id.etMessage);
        btnCheck = findViewById(R.id.btnCheck);
        tvResult = findViewById(R.id.tvResult);

        etPhone = findViewById(R.id.etPhone);
        btnCheckPhone = findViewById(R.id.btnCheckPhone);

        // Fraud message checker
        btnCheck.setOnClickListener(v -> {
            String msg = etMessage.getText().toString().toLowerCase();

            if (TextUtils.isEmpty(msg)) {
                tvResult.setText("⚠️ Please paste a message first.");
                return;
            }

            if (isFraud(msg)) {
                tvResult.setText("🚨 Fraud Alert! This message looks suspicious.");
                tvResult.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            } else {
                tvResult.setText("✅ Safe! This message looks genuine.");
                tvResult.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            }
        });

        // Phone number region checker
        btnCheckPhone.setOnClickListener(v -> {
            String input = etPhone.getText().toString().trim();
            if (input.isEmpty()) {
                Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show();
                return;
            }
            checkPhoneRegion(input);
        });
    }

    // ✅ Fraud check method
    private boolean isFraud(String msg) {
        String[] fraudKeywords = {"lottery", "prize", "urgent", "atm blocked",
                "kyc update", "gift", "winner", "click here", "free"};

        String[] fraudLinks = {"bit.ly", "tinyurl", "free-gift", "winbig"};

        for (String word : fraudKeywords) {
            if (msg.contains(word)) return true;
        }

        for (String link : fraudLinks) {
            if (msg.contains(link)) return true;
        }

        return false;
    }

    // ✅ Phone number region check method
    private void checkPhoneRegion(String numberInput) {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        String defaultRegion = Locale.getDefault().getCountry(); // e.g., IN, US

        try {
            Phonenumber.PhoneNumber numberProto = phoneUtil.parse(numberInput, defaultRegion);

            // Get location description
            String description = PhoneNumberOfflineGeocoder.getInstance()
                    .getDescriptionForNumber(numberProto, Locale.getDefault());

            if (description == null || description.isEmpty()) {
                String regionCode = phoneUtil.getRegionCodeForNumber(numberProto);
                description = (regionCode != null) ? new Locale("", regionCode).getDisplayCountry() : "Unknown";
            }

            tvResult.setText("📍 Phone belongs to: " + description);

            // Open Google Maps with that region
            Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + Uri.encode(description));
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            startActivity(mapIntent);

        } catch (NumberParseException e) {
            tvResult.setText("❌ Could not parse number: " + e.getMessage());
        }
    }
}
